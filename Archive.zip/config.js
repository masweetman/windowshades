/* Copy to config.js and configure */
var config = {};

// PowerView Hub Hostname
// example: test.com
config.host = '23.93.17.186:3231';

// set open scene endpoints
// example: 'scenecollections?sceneCollectionID=123'
//   or 'scenes?sceneID=123'
config.openAll = 'scenecollections?sceneCollectionID=47516';
config.openBedroom = 'scenes?sceneID=42747';
config.openStairs = 'scenes?sceneID=19831';
config.openLivingRoom = 'scenes?sceneID=11188';

//set close scene endpoints
config.closeAll = 'scenecollections?sceneCollectionID=2512';
config.closeBedroom = 'scenes?sceneID=38045';
config.closeStairs = 'scenes?sceneID=34071';
config.closeLivingRoom = 'scenes?sceneID=60099';

//set partial scene endpoints
config.partialAll = 'scenecollections?sceneCollectionID=21420';
config.partialBedroom = 'scenes?sceneID=58576';
config.partialStairs = 'scenes?sceneID=33310';
config.partialLivingRoom = 'scenes?sceneID=18308';

module.exports = config;
